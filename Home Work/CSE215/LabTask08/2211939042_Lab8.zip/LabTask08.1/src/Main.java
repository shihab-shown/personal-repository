public class Main {
    public static void main(String[] args) throws Exception {   
        Rectangle rectangle1 = new Rectangle(2,20);
        Rectangle rectangle2 = new Rectangle(3.5,35.9);
        System.out.print(rectangle1);
        System.out.print(rectangle2);
    }
}
