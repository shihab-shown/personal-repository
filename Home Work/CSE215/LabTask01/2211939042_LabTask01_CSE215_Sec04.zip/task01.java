public class task01 {
  public static void main(String[] args) {
    int celsius = 32;
    float fahrenheit = (float)(9.0/5)*celsius + 32;
    System.out.println("Fahrenheit: "+fahrenheit);
  }
}
