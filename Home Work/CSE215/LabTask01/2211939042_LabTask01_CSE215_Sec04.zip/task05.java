public class task05 {
  public static void main(String[] args) {
    int x1 = 4, x2 = 13, y1 = 7, y2 = 21;
    int result = Math.abs(x1-x2) + Math.abs(y1-y2);
    System.out.println("The Manhattan Distance is: "+result);
  }
}
