public class task04 {
  public static void main(String[] args) {
    double time = ((45.0*60)+30)/3600;
    double speed = 14 * (1/1.6);
    System.out.println("Avarage speed is: "+ (speed/time));
  }
}
