public class task03 {
  public static void main(String[] args) {
    double base = 4.5, height = 6.5;
    double area = 0.5 * base * height ;
    System.out.printf("Area: %.2f\n",area);
  }
}
